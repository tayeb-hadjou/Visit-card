module.exports = {
  SECRET_TOKEN : 'jwtSecretKey'
}
